// завдання 1.
function countVowels(str){
    let count = 0;

    const vowels = "aeiou";

    for(let symbol of str.toLowerCase()){
        if (vowels.includes(symbol)){
            count += 1;
        }
    }

    return count;
}
console.log("Task 1.---------------------");
console.log(countVowels("Hello World! It's a big boom!"));

// завдання 2.

function secondLargest(arr){
    const sortedArr = arr.slice().sort((a,b) => a - b);

    const len = sortedArr.length;

    return sortedArr[len-2];
}
console.log("Task 2.---------------------");
console.log(secondLargest([1, 4, -20, 11, 7, 0, 2]));

// або спосіб 2

function secondLargest2(arr){
    let largest = -10000000000000;
    let secondLargest = -10000000000000;
    for (let i = 0; i < arr.length; i++){
        let currNum = arr[i];

        if(currNum > largest){
            largest = currNum;
            secondLargest = largest
        }

        else if(currNum > secondLargest && currNum != largest){
            secondLargest = currNum;
        }
    }

    return secondLargest;
}

console.log(secondLargest([1, 4, -20, 11, 7, 0, 2]));
console.log(secondLargest([5, 5, 5]));

// завдання 3.
function isAnagram(str1, str2){
    const sortStr1 = str1.toLowerCase().split('').sort().join('');
    const sortStr2 = str2.toLowerCase().split('').sort().join('');

    return sortStr1 === sortStr2;
}
console.log("Task 3.---------------------");
console.log(isAnagram("listen", "silent"));
console.log(isAnagram("listener", "silent"));

// завдання 4.
function twoSum(arr, target){

    for(let i = 0; i < arr.length; i++){
        for(let j = i+1; j < arr.length; j++){
            if(arr[i]+arr[j] == target){
                return [i, j];
            }
        }
    }
    return "Nothing found";
}
console.log("Task 4.---------------------");
console.log(twoSum([2, 3, 7, 15], 9));

// завдання 5.
function isPalindrome(str){
    const Nstr = str.split('').reverse().join('');
    return str == Nstr
}

console.log("Task 5.---------------------");
console.log(isPalindrome("racecar"));

// завдання 6.
const numberInput = document.getElementById('numberInput');
const result = document.getElementById('result');

function convertToRoman(num){
    const thousands = ["", "M", "MM", "MMM"];
    const hundreds = ["", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM"];
    const tens = ["", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"];
    const ones = ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"];

    let roman = thousands[Math.floor(num / 1000)];
    roman += hundreds[Math.floor((num % 1000) / 100)];
    roman += tens[Math.floor((num % 100) / 10)];
    roman += ones[num % 10];

    return roman;
}

numberInput.addEventListener('input', () =>{
    const inputValue = parseInt(numberInput.value);

    if (inputValue >= 1 && inputValue <= 3999){
        result.textContent = convertToRoman(inputValue);
    }
    else{
        result.textContent = 'Error';
    }
})
