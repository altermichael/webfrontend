import classes from './items.module.css'
import { itemsData } from './items.data.js'
import { ItemComponent } from './item.component/item.component.js'

export const ItemsComponent = () => {

    return (
        <div className={classes.TheMain}>
            <div className={classes.main}>
                <div className={classes.ContTitle}>Featured Products</div>
                <div className={classes.container}>
                    {itemsData.map((element, index) => (
                        <ItemComponent key={index} data={element} />
                    ))}
                </div>
            </div>
        </div>
    )
}