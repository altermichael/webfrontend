export const itemsData = [
    {
        image: "/imgs/arne_jacobsen_egg_chair_blue_1_medium.avif",
        title: "Arne Jacobsen Egg Chair blue",
        price: "220.00",
        salePrice: "199.00",
        currency: '$'
    },
    {
        image: "/imgs/attractive_round_chair_on_low_revolving_base_1_medium.avif",
        title: "Attractive round chair on low revolving base",
        price: "60.00",
        currency: '$'
    },
    {
        image: "/imgs/avenue_six_roundabout_spring_green_low_circle_lounger_1_medium.avif",
        title: "Avenue Six Roundabout Spring Green Low Circle Lounger",
        price: "78.00",
        currency: '$'
    },
    {
        image: "/imgs/camilla_armchair_1_medium.avif",
        title: "CAMILLA Armchair",
        price: "469.00",
        currency: '$'
    },
    {
        image: "/imgs/le_corbusier_armchair_1_medium.avif",
        title: "Le Corbusier Armchair",
        price: "500.00",
        salePrice: "399.00",
        currency: '$'
    },
    {
        image: "/imgs/le_corbusier_lc7_chair_furniture_1_medium.avif",
        title: "Le Corbusier LC7 Chair furniture",
        price: "420.00",
        currency: '$'
    },
    {
        image: "/imgs/mesa_modern_round_dining_table_1_medium.avif",
        title: "Mesa Modern Round Dining Table",
        price: "265.00",
        currency: '$'
    },
    {
        image: "/imgs/miss_k_table_lamp_by_flos_1_medium.avif",
        title: "Miss K Table Lamp by Flos",
        price: "170.00",
        currency: '$'
    },
    {
        image: "/imgs/modern_contemporary_self_storage_furniture_hipster_by_zuo_modern_1_medium.avif",
        title: "Modern Contemporary Self Storage",
        price: "400.00",
        salePrice: "320.00",
        currency: '$'
    },
    {
        image: "/imgs/modern_design_cardboard_wiggle_chair_1_medium.avif",
        title: "Modern Design Cardboard Wiggle Chair",
        price: "265.00",
        currency: '$'
    },
    {
        image: "/imgs/oksana_dining_table_1_medium.avif",
        title: "Oksana Dining Table",
        price: "199.00",
        currency: '$'
    },
    {
        image: "/imgs/pk20_easy_chair_by_designer_poul_kjaerholm_for_fritz_hansen_1_medium.avif",
        title: "PK20 Easy Chair by Designer Poul",
        price: "60.00",
        currency: '$'
    },
]