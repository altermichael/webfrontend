
import styles from './item.module.css';

export const ItemComponent = (props) => {
    const { image, title, price, salePrice, currency } = props.data;

    let realPrice;

    if(salePrice){
        realPrice =(
            <div className={styles.salePrice}>{currency}{salePrice}<span className={styles.sale_old}>{currency}{price}</span></div>
        )
    }

    else{
        realPrice =(
            <div className={styles.price}>{currency}{price}</div>
        )
    }

    return (
        <div className={styles.card}>
            <div className={styles.ForHidden}>
                <div className={styles.for_img}>
                    <img src={image} alt={title} className={styles.image} />
                    
                    {salePrice && <span className={styles.saleBadge}>SALE</span>}
                    {salePrice && <span className={styles.saleBadgeElement}></span>}
                </div>
                
                <div className={styles.info}>
                    <div className={styles.title}>{title}</div>
                    
                    <div className={styles.for_price}>
                        {realPrice}
                    </div>
                    
                </div>
            </div>
        </div>
    );
}