import './header.component.css'

export const HeaderComponent = () => {
    return(
    <div className="header">
        <div className='forHeader'>
            <div className='leftSide'>
                <div className="mainTitle">Furniture<span className="mainTitleG">Store</span></div>
                <div className='miniTitleL'>The biggest choice on the web</div>
            </div>

            <div className='rightSide'>
                <div className='ActMenu'>
                    <span className='Act'>Log in</span>
                    <span className='Act'>Create an account</span>
                    <span className='Act'>Check out</span>
                </div>

                <div className='Cart'>
                    <span className='CartImg'><img src='/imgs/shopping-cart.png'/></span>
                    <span className='CartDescription'>
                        <span className='boldCD'>My cart: </span> 0 item(s) - <span className='boldCD'>$0.00</span>
                    </span>
                </div>

                <div className='Search'>
                    <div className='SearchField'>
                        <input type='text' placeholder='Search store...' className='SearchBox'/>
                        <div className='forSearchImg'>
                            <img src='/imgs/magnifying-glass.png'/>
                        </div>
                    </div>
                </div>       
            </div>
        </div>

    </div>

    );
}