import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import cls from './authors.module.css';
import { getAuthors, getPostsByAuthorId } from '../../services/blogService';


export const AuthorsComponent = () => {
    const [authors, setAuthors] = useState([]);

    useEffect(() => {
        getAuthors().then(data => {
            setAuthors(data);
        });
    }, []);

    return (
        <div className={cls.authorsPageContainer}>
            <h1 className={cls.pageTitle}>Authors page</h1>
            <div className={cls.cards}>
                {authors.map((author) => (
                    <AuthorItem key={author.id} author={author} />
                ))}
            </div>
        </div>
    );
};


const AuthorItem = ({ author }) => {
    const [posts, setPosts] = useState([]);

    useEffect(() => {
        getPostsByAuthorId(author.id).then(data => setPosts(data));
    }, [author.id]);

    return (
        <div className={cls.card}>
            
            <div className={cls.leftInfo}>
                <div className={cls.avatar}></div>
                <div className={cls.infoText}>
                    <h3 className={cls.authorName}>{author.name}</h3>
                    <div className={cls.authorDetails}>{author.email}</div>
                    <div className={cls.authorDetails}>{author.phone}</div>
                </div>
            </div>

            <div className={cls.rightPosts}>
                {posts.map(post => (
                    <div className={cls.singlePostCard} key={post.id}>
                        <span className={cls.postTitle}>
                            {post.title}
                        </span>
                        <Link to={`/posts/${post.id}`} style={{ textDecoration: 'none' }}>
                            <button className={cls.openButton}>open</button>
                        </Link>
                    </div>
                ))}
            </div>
        </div>
    );
};